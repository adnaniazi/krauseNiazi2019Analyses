.onLoad <-
function(libname, pkgname) {
  library.dynam("RSvgDevice", pkgname, libname)
}
